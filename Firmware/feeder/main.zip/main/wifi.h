/*
 * WIFI.h
 *
 *  Created on: Jan 15, 2025
 *      Author: Matheus
 */
 #ifndef _WIFI
 #define _WIFI


void wifi_init(void);




#endif /* _WIFI */